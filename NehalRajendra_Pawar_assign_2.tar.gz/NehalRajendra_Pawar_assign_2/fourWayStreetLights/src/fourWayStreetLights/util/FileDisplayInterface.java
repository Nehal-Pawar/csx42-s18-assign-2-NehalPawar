package fourWayStreetLights.util;

public interface FileDisplayInterface {

	//This interface should have a method void writeToFile(String s);
	public void writeToFile(String s);
}
